<?php


return [
    '' => 'AthleteController@index',            // List all athletes
    'athlete/create' => 'AthleteController@create', // Show registration form
    'athlete/store'  => 'AthleteController@store',  // Handle form submission
];
